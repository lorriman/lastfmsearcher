import 'package:jobtest_lastfm/app/top_level_providers.dart';
import 'package:flutter/material.dart';
import 'app/home_page.dart';

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        visualDensity: VisualDensity.standard,
        primarySwatch: Colors.lightGreen,
        textSelectionTheme:
            TextSelectionThemeData(selectionHandleColor: Colors.transparent),
      ),
      darkTheme: ThemeData(
        primarySwatch: Colors.lightGreen,
        brightness: Brightness.dark,
      ),
//      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

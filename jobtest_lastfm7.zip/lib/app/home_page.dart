import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:jobtest_lastfm/app/top_level_providers.dart';
import 'package:jobtest_lastfm/services/lastfmapi.dart';
import 'package:jobtest_lastfm/services/utils.dart';

import 'package:jobtest_lastfm/services/repository.dart';

import 'models/item.dart';
import 'models/viewmodel.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? _radioGroupValue = musicInfoTypeStrings[MusicInfoType.albums];
  late final TextEditingController _textController;

//  final _repository = TestRepository(); //Repository(database: TestDatabase());

  //LastfmDatabase(apiKey: '5b162553274ad0ff3d5a71d798de3f2c'));

  //LastfmDatabase(apiKey: '5b162553274ad0ff3d5a71d798de3f2c'));

  void _onRadioChanged(dynamic value) {
    setState(() {
      return;
      _radioGroupValue = value as String;
    });
  }

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer(builder: (context, watch, _) {
      final viewModel = watch(viewModelProvider);
      return GestureDetector(
        //keyboard pop-down
        onTapDown: (_) => FocusManager.instance.primaryFocus?.unfocus(),
        behavior: HitTestBehavior.translucent,
        child: Scaffold(
          appBar: AppBar(
            title: Text(
              'Searcher for LastFM',
              maxLines: 2,
              semanticsLabel: 'app title: LastFM searcher',
            ), //Strings.checklistItems),
            actions: [
              Container(
                width: 150,
                child: _searchField(viewModel),
              ),
              IconButton(
                  icon: Icon(Icons.search, semanticLabel: 'search button'),
                  onPressed: () => viewModel.fetch()),
            ],
          ),
          body: Column(
            children: [
              Container(height: 40, child: _radioButtons()),
              Consumer(
                builder: (context, watch, _) {
                  final modelsAsyncValue = watch(musicInfoProvider);
                  return modelsAsyncValue.when(
                    loading: () => Center(
                        child: basicLoadingIndicator('waiting for LastFM')),
                    error: (e, st) => Text('Error $e'),
                    data: (data) =>
                        Expanded(child: _listView(context, data, viewModel)),
                  );
                },
              )
            ],
          ),
        ),
      );
    });
  }

  Widget _searchField(MusicViewModel viewModel) {
    return Theme(
      data: ThemeData(
          textSelectionTheme: TextSelectionThemeData(
        selectionColor: Colors.grey,
      )),
      child: TextField(
        controller: _textController,
        onTap: () {
          _textController.selection = TextSelection(
            baseOffset: 0,
            extentOffset: viewModel.searchString.length,
          );
        },
        autofocus: true,
        focusNode: FocusNode(),
        textAlign: TextAlign.end,
        decoration: InputDecoration(
          hintStyle: TextStyle(color: Colors.grey[300]),
          hintText: 'album, artist or song',
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.white),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.white),
          ),
          border: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.white),
          ),
        ),
        cursorColor: Colors.black,
        showCursor: true,
        onChanged: (value) {
          viewModel.searchString = value;
        },
      ),
    );
  }

  Widget _radioButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Text('albums'),
        Radio(
            value: 'albums',
            groupValue: _radioGroupValue,
            onChanged: _onRadioChanged),
        Text('songs'),
        Radio(
            value: 'songs',
            groupValue: _radioGroupValue,
            onChanged: _onRadioChanged),
        Text('artists'),
        Radio(
            value: 'artists',
            groupValue: _radioGroupValue,
            onChanged: _onRadioChanged),
      ],
    );
  }

  Widget _listView(
      BuildContext context, List<MusicInfo>? items, MusicViewModel viewModel) {
    int computeElementCount() {
      if (items == null) return 1;
      if (viewModel.status == FetchType.complete) return items.length;
      return items.length + 1;
    }

    return ListView.builder(
      //add an extra for a loadingIndicator when the user
      // scrolls down to the last element, but not if there are no more items
      itemCount: computeElementCount(),
      itemBuilder: (context, idx) {
        final itemCount = items?.length ?? 0;
        if (viewModel.status != FetchType.first &&
            itemCount > 0 &&
            idx == itemCount) {
          final repo = context.read(repositoryProvider).state;
          //the delay is to make sure the loading indicator always shows
          repo.next(UIdelayMillisecs: 350).then((noNewData) {
            if (noNewData) {
              setState(() => viewModel.status == FetchType.complete);
            }
          });
          return basicLoadingIndicator('waiting for LastFM');
        }
        if (itemCount == 0) return Center(child: Text('No items found'));

        return Card(
            margin: EdgeInsets.all(5),
            elevation: 10.0,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(items?[idx].name ?? 'null item'),
            ));
      },
    );
  }
}

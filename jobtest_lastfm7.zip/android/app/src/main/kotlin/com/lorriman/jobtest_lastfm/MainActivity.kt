package com.lorriman.jobtest_lastfm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
